package com.johndang.gettingfamiliarrouting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GettingFamiliarRoutingApplication {

	public static void main(String[] args) {
		SpringApplication.run(GettingFamiliarRoutingApplication.class, args);
	}

}
