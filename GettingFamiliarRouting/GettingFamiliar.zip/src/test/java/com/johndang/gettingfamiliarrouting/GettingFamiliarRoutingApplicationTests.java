package com.johndang.gettingfamiliarrouting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GettingFamiliarRoutingApplicationTests {

	@Test
	void contextLoads() {
	}

}
