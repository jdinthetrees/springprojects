package com.johndang.displaydate;

import org.springframework.stereotype.Controller;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.ui.Model;


import java.util.Date;


@Controller

public class HomeController {
    @RequestMapping("/")
    public String index() {
        return "index.jsp";
    }
    
    @RequestMapping("/date")
    //import localdate, datetimeformatter and format like so
    public String date(Model model) {
    	LocalDate date = LocalDate.now();
    	DateTimeFormatter theDate = DateTimeFormatter.ofPattern("EEEE, ' the' dd' of ' MMMM, YYYY");
    	
    	
    	model.addAttribute("date", date.format(theDate));
        return "date.jsp";
    }
    
    @RequestMapping("/time")
    public String time(Model model) {
    	
    	model.addAttribute("time", "11:30 PM");
        return "time.jsp";
    }
    
    
}
